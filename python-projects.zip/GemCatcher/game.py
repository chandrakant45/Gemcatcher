import pgzrun
import random

WIDTH = 800
HEIGHT = 600
WHITE = (255, 255, 255)
black = (0, 0, 0)
ship = Actor('player')
ship.x = 370
ship.y = 550
gem = Actor('gem')
gem.x = random.randint(20, 780)
gem.y = 0
score = 0
game_over = False

def draw():
    screen.fill('black')
    if game_over:
        screen.draw.text('Game Over!!', (250, 200), color= WHITE, fontsize=60)
        screen.draw.text('Score: ' + str(score), (250,250), color= WHITE, fontsize=60)
    else:
        gem.draw()
        ship.draw()
        screen.draw.text('Score: ' + str(score), (15,10), color= WHITE, fontsize=30)

def update():
    move_ship()
    check_ship_boundaries()
    check_collision()

def move_ship():
    if keyboard.left:
        ship.x = ship.x - 5
    if keyboard.right:
        ship.x = ship.x + 5

def check_collision():
    global score, game_over
    gem.y = gem.y + 4 + score / 5
    if gem.y > 600:
        game_over = True
    if gem.colliderect(ship):
        gem.x = random.randint(20, 780)
        gem.y = 0
        score = score + 1

def  check_ship_boundaries():
    if ship.right > WIDTH:
       ship.right = WIDTH
    if ship.left < 0:
        ship.left = 0
    if ship.top < 0:
        ship.top = 0
    if ship.bottom > HEIGHT:
       ship.bottom = HEIGHT

def on_mouse_move(pos):
    ship.x = pos[0]

pgzrun.go()