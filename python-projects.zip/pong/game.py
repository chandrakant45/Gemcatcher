import pgzrun

WIDTH = 800
HEIGHT = 500
ORANGE = (252, 111, 3)
WHITE = (225, 225, 225)
ball = Actor('ball')
paddle = Actor('paddle')
paddle.x = 100
paddle.y = HEIGHT - 16
ball_velocity_x = 4
ball_velocity_y = 2
score = 0
missed = False

def draw():
    screen.fill(ORANGE)
    ball.draw()
    paddle.draw()
    screen.draw.text("score: "+str(score), (10, 10), fontsize=25, color=WHITE)
    if missed:
        screen.draw.text("oops! you missed the ball,Game Over!!", (200, 100), fontsize=40, color=WHITE)

def update():
    if not missed:
        ball.right += ball_velocity_x
        ball.bottom += ball_velocity_y
        check_boundaries()
        detect_collision()
        check_paddle_miss()

def on_mouse_move(pos):
    if not missed:
        paddle.left = pos[0]
    if paddle.left < 0:
        paddle.left = 0
    if paddle.right > WIDTH:
        paddle.right = WIDTH

def check_boundaries():
    global ball_velocity_x,ball_velocity_y
    if ball.right > WIDTH or ball.left < 0:
        ball_velocity_x *= -1
    if ball.top < 0:
        ball_velocity_y *= -1

def detect_collision():
    global ball_velocity_y,score
    if ball.colliderect(paddle):
        score += 1
        ball_velocity_y *= -1

def check_paddle_miss():
    global missed
    if ball.bottom > paddle.top + abs(ball_velocity_y):
        missed = True

pgzrun.go()


