import string
import pgzrun
from random import choice, randint
WIDTH = 800
HEIGHT = 600
GREEN = (144, 245, 66)
PINK = (252, 3, 57)
letter = {'alphabet': '', 'x': 0, 'y': 0}
letter_velocity = 5

rigth_score = 0
wrong_score = 0


def draw():
    screen.fill(GREEN)
    screen.draw.text(letter['alphabet'], (letter['x'], letter['y']), fontsize=70, color=PINK)
    screen.draw.text("right score: ")

def update():
    letter['y'] += letter_velocity
    if letter['y'] > HEIGHT:
        get_new_letter()


def on_key_down(unicode):
    if unicode:
         if unicode == letter['alphabet']:
                get_new_letter()


def get_new_letter():
    letter['alphabet'] = choice(string.ascii_lowercase)
    letter['x'] = randint(10, WIDTH-10)
    letter['y'] = 10







get_new_letter()
pgzrun.go()
